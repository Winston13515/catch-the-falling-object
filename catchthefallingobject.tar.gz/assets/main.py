
import pygame
import random
import sys
import asyncio

pygame.init()

# =====================================
# PENGATURAN LAYAR
# =====================================

WIDTH = 800
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Catch the Falling Object")

clock = pygame.time.Clock()

# =====================================
# WARNA
# =====================================

WHITE = (255, 255, 255)
BLUE = (50, 130, 255)
YELLOW = (255, 210, 50)
RED = (255, 70, 70)
GREEN = (50, 220, 130)
DARK_BLUE = (25, 30, 60)

# =====================================
# FONT
# =====================================

font = pygame.font.SysFont("Arial", 28)
big_font = pygame.font.SysFont("Arial", 50)

# =====================================
# KARAKTER / KERANJANG
# =====================================

player_width = 100
player_height = 25

player = pygame.Rect(
    WIDTH // 2 - player_width // 2,
    HEIGHT - 80,
    player_width,
    player_height
)

player_speed = 9

# =====================================
# PENGATURAN BENDA JATUH
# =====================================

object_size = 25

BASE_SPAWN_INTERVAL = 900
SPAWN_INTERVAL_DECREASE = 10
MIN_SPAWN_INTERVAL = 600

BASE_OBJECT_SPEED = 3.5
SPEED_INCREMENT = 0.25

BOUNCE_SPEED = 4

SPAWN_MARGIN = 50

MIN_OBJECT_DISTANCE = 70
MAX_OBJECT_DISTANCE = 300

falling_objects = []

last_spawn_time = 0

# =====================================
# STATUS GAME
# =====================================

score = 0
lives = 3
level = 1

game_over = False

# =====================================
# MEMBUAT BENDA BARU
# =====================================

def spawn_object():

    min_x = SPAWN_MARGIN
    max_x = WIDTH - object_size - SPAWN_MARGIN

    if len(falling_objects) == 0:

        x = random.randint(min_x, max_x)

    else:

        last_x = falling_objects[-1]["rect"].x

        direction = random.choice([-1, 1])

        distance = random.randint(
            MIN_OBJECT_DISTANCE,
            MAX_OBJECT_DISTANCE
        )

        x = last_x + (direction * distance)

        if x < min_x or x > max_x:
            x = last_x - (direction * distance)

        if x < min_x or x > max_x:
            x = random.randint(min_x, max_x)

    obj = {
        "rect": pygame.Rect(
            x,
            -object_size,
            object_size,
            object_size
        ),

        "speed_y": BASE_OBJECT_SPEED + (
            (level - 1) * SPEED_INCREMENT
        ),

        "speed_x": 0
    }

    falling_objects.append(obj)


# =====================================
# RESET GAME
# =====================================

def reset_game():

    global score, lives, level
    global game_over, last_spawn_time

    score = 0
    lives = 3
    level = 1

    game_over = False

    player.x = WIDTH // 2 - player_width // 2

    falling_objects.clear()

    last_spawn_time = pygame.time.get_ticks()


# =====================================
# GAMBAR GAME
# =====================================

def draw_game():

    screen.fill(DARK_BLUE)

    # Menggambar keranjang
    pygame.draw.rect(
        screen,
        BLUE,
        player,
        border_radius=10
    )

    # Menggambar benda jatuh
    for obj in falling_objects:

        pygame.draw.circle(
            screen,
            YELLOW,
            obj["rect"].center,
            object_size // 2
        )

    # Menampilkan skor
    score_text = font.render(
        f"Score: {score}",
        True,
        WHITE
    )

    # Menampilkan nyawa
    lives_text = font.render(
        f"Lives: {lives}",
        True,
        WHITE
    )

    # Menampilkan level
    level_text = font.render(
        f"Level: {level}",
        True,
        GREEN
    )

    screen.blit(score_text, (20, 20))
    screen.blit(lives_text, (20, 60))
    screen.blit(level_text, (20, 100))


# =====================================
# GAME LOOP ASYNC UNTUK PYGBAG
# =====================================

async def main():

    global game_over
    global score, lives, level
    global last_spawn_time

    running = True

    while running:

        clock.tick(60)

        # =================================
        # EVENT
        # =================================

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                if event.key == pygame.K_r and game_over:
                    reset_game()

        # =================================
        # BACKGROUND
        # =================================

        screen.fill(DARK_BLUE)

        if not game_over:

            # =================================
            # INPUT KEYBOARD
            # =================================

            keys = pygame.key.get_pressed()

            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                player.x -= player_speed

            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                player.x += player_speed

            # Membatasi gerakan keranjang
            player.left = max(0, player.left)
            player.right = min(WIDTH, player.right)

            # =================================
            # SPAWN BENDA
            # =================================

            current_time = pygame.time.get_ticks()

            current_spawn_interval = max(
                BASE_SPAWN_INTERVAL -
                (level - 1) * SPAWN_INTERVAL_DECREASE,
                MIN_SPAWN_INTERVAL
            )

            if (
                current_time - last_spawn_time
                >= current_spawn_interval
            ):

                spawn_object()

                last_spawn_time = current_time

            # =================================
            # UPDATE BENDA JATUH
            # =================================

            for obj in falling_objects[:]:

                falling_rect = obj["rect"]

                previous_bottom = falling_rect.bottom

                # Gerakan benda
                falling_rect.y += obj["speed_y"]
                falling_rect.x += obj["speed_x"]

                # =================================
                # PANTULAN DINDING LAYAR
                # =================================

                if falling_rect.left <= 0:

                    falling_rect.left = 0

                    obj["speed_x"] = abs(
                        obj["speed_x"]
                    )

                if falling_rect.right >= WIDTH:

                    falling_rect.right = WIDTH

                    obj["speed_x"] = -abs(
                        obj["speed_x"]
                    )

                # =================================
                # COLLISION DETECTION
                # =================================

                if falling_rect.colliderect(player):

                    # Menangkap dari atas
                    if (
                        previous_bottom <= player.top
                        and falling_rect.bottom >= player.top
                        and falling_rect.centerx > player.left
                        and falling_rect.centerx < player.right
                        and obj["speed_y"] > 0
                    ):

                        score += 1

                        falling_objects.remove(obj)

                        # Level naik setiap 5 skor
                        new_level = (score // 5) + 1

                        if new_level > level:
                            level = new_level

                        continue

                    else:

                        # Pantulan dari sisi keranjang
                        if falling_rect.centerx < player.centerx:

                            falling_rect.right = player.left

                            obj["speed_x"] = -BOUNCE_SPEED

                        else:

                            falling_rect.left = player.right

                            obj["speed_x"] = BOUNCE_SPEED

                # =================================
                # BENDA TERLEWAT
                # =================================

                if falling_rect.top > HEIGHT:

                    falling_objects.remove(obj)

                    lives -= 1

                    if lives <= 0:

                        game_over = True

                        break

            # =================================
            # GAMBAR GAME
            # =================================

            draw_game()

        # =====================================
        # GAME OVER
        # =====================================

        else:

            game_over_text = big_font.render(
                "GAME OVER",
                True,
                RED
            )

            final_score_text = font.render(
                f"Skor Akhir: {score}",
                True,
                WHITE
            )

            restart_text = font.render(
                "Tekan R untuk bermain lagi",
                True,
                GREEN
            )

            exit_text = font.render(
                "Tekan ESC untuk keluar",
                True,
                WHITE
            )

            screen.blit(
                game_over_text,
                (
                    WIDTH // 2 - game_over_text.get_width() // 2,
                    200
                )
            )

            screen.blit(
                final_score_text,
                (
                    WIDTH // 2 - final_score_text.get_width() // 2,
                    280
                )
            )

            screen.blit(
                restart_text,
                (
                    WIDTH // 2 - restart_text.get_width() // 2,
                    350
                )
            )

            screen.blit(
                exit_text,
                (
                    WIDTH // 2 - exit_text.get_width() // 2,
                    400
                )
            )

        # =====================================
        # UPDATE DISPLAY
        # =====================================

        pygame.display.flip()

        # Penting untuk Pygbag:
        # Memberikan kesempatan browser menjalankan proses lain.
        await asyncio.sleep(0)

    pygame.quit()


# =====================================
# MENJALANKAN GAME
# =====================================

asyncio.run(main())
